package com.example.databaseotto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

        EditText nombreField, emailField, passwordField, edadField;
        Button registrobtn;
        FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        nombreField = (EditText) findViewById(R.id.eTextNombre);
        emailField = (EditText) findViewById(R.id.eTextEmail);
        passwordField = (EditText) findViewById(R.id.eTextPassword);
        edadField = (EditText) findViewById(R.id.eTextEdad);

        registrobtn = (Button) findViewById(R.id.buttonRegistro);
        registrobtn.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.buttonRegistro:
                registrarParticipante();
                break;
        }
    }

    private void registrarParticipante() {
        String nombre = nombreField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        String edad = edadField.getText().toString().trim();

        if (nombre.isEmpty()){
            nombreField.setError("Nombre es requerido");
            nombreField.requestFocus();
            return;
        }
        if (email.isEmpty()){
            emailField.setError("Email es requerido");
            emailField.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailField.setError("Ingrese un email valido");
            emailField.requestFocus();
            return;
        }
        if(password.isEmpty()){
            passwordField.setError("Password es requerido");
            passwordField.requestFocus();
            return;
        }
        if(password.length()<6) {
            passwordField.setError("Password requiere por lo menos 6 caracteres");
            passwordField.requestFocus();
            return;
                                 }
            if(edad.isEmpty()){
                edadField.setError("Inserte su edad");
                edadField.requestFocus();
                return;

            }
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Visitor persona = new Visitor(nombre, email, password, edad);
                            Task<Void> voidTask = FirebaseDatabase.getInstance().getReference("Visitors")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(persona).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(MainActivity.this, "Participante registrado", Toast.LENGTH_LONG).show();
                                                LimpiarFormulario();
                                            } else {
                                                Toast.makeText(MainActivity.this, "Error, no se pudo registrar el participante", Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                        }

                    }
                });
    }

    private void LimpiarFormulario() {
        nombreField.setText("");
        emailField.setText("");
        passwordField.setText("");
        edadField.setText("");
    }
}