package com.example.databaseotto;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;


import java.util.ArrayList;

public class FirebaseHelper {
    DatabaseReference db;
    Boolean saved = null;
    ArrayList<String> visitors = new ArrayList<>();

    public FirebaseHelper(DatabaseReference db) {
        this.db = db;
    }

    public Boolean save(Visitor visitor) {
        if (visitor == null) {
            saved = false;
        } else {
            try {
                db.child("Visitors").push().setValue(visitor);
                saved = true;
            } catch (DatabaseException e) {
                e.printStackTrace();
                saved = false;
            }
        }
        return saved;
    }
    public ArrayList<String> retrieve(){
        db.addChildEventListener(new ChildEventListener(){
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s){
                fetchData(dataSnapshot);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                fetchData(dataSnapshot);
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                fetchData(dataSnapshot);
            }

            @Override
            public void onChildMoved(DataSnapshot snapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
        return visitors;
    }
    private void fetchData(DataSnapshot dataSnapshot){
        visitors.clear();
        for (DataSnapshot ds: dataSnapshot.getChildren()){
            String nombrelista = ds.getValue(Visitor.class).nombre;
            visitors.add(nombrelista);
            String emaillista = ds.getValue(Visitor.class).email;
            visitors.add(emaillista);
            String passwordlista = ds.getValue(Visitor.class).password;
            visitors.add(passwordlista);
            String edadlista = ds.getValue(Visitor.class).edad;
            visitors.add(edadlista);
        }
    }
}
