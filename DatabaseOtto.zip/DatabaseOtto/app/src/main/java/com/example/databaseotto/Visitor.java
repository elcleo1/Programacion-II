package com.example.databaseotto;

public class Visitor {
    public String nombre, email, password, edad;

    public Visitor(){}

    public Visitor(String nombre, String email, String password, String edad) {
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.edad = edad;
    }
}
