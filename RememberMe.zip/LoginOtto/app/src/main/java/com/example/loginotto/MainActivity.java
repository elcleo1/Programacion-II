package com.example.loginotto;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText Username, Password;
    Button Login, Clear;
    private CheckBox Rememberme;
    private SharedPreferences mPrefs;
    private static final String PREFS_NAME = "PrefsFile";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        Username = findViewById(R.id.loginuser);
        Password = findViewById(R.id.loginpassword);
        Login = findViewById(R.id.loginbtn);
        Clear = findViewById(R.id.clearbtn);
        Rememberme = (CheckBox) findViewById(R.id.checkboxremember);
        getPreferencesData();
        Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Username.getText().clear();
                Password.getText().clear();
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Username.getText().toString().equals("admin") && Password.getText().toString().equals("admin")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(
                            MainActivity.this
                    );
                    if(Rememberme.isChecked()){
                        Boolean boolIsChecked = Rememberme.isChecked();
                        SharedPreferences.Editor editor = mPrefs.edit();
                        editor.putString("pref_name", Username.getText().toString());
                        editor.putString("pref_pass", Password.getText().toString());
                        editor.putBoolean("pref_check", boolIsChecked);
                        editor.apply();
                        Toast.makeText(getApplicationContext(), "Datos Salvados", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        mPrefs.edit().clear().apply();
                    }
                    builder.setIcon(R.drawable.ic_check);
                    builder.setTitle("Login Exitoso!");
                    builder.setMessage("Bienvenidos a la aplicacion");
                    builder.setNegativeButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    openActivity2();
                }
                else {
                    Toast.makeText(getApplicationContext(),
                            "Usuario o Clave Invalida.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void openActivity2() {
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }
    private void getPreferencesData() {
        SharedPreferences sp = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if(sp.contains("pref_name")){
            String u = sp.getString("pref_name", "not found.");
            Username.setText(u.toString());
        }
        if(sp.contains("pref_pass")){
            String p = sp.getString("pref_pass", "not found.");
            Password.setText(p.toString());
        }
        if(sp.contains("pref_check")){
            Boolean b = sp.getBoolean("pref_check", false);
            Rememberme.setChecked(b);
        }
    }
}
