package com.example.asistenteeventos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

import static java.lang.Math.round;
//Creado por Otto Obritzhauser 19-0632
public class MainActivity extends AppCompatActivity {
    ListView listViewData;
    ArrayAdapter<String> adapter;
    String[] arrayNombres = {"M - Otto", "F - Zoe", "M - Manuel", "F - Laura", "M - Alejandro", "F - Maria", "M - Roberto", "M - Jose", "F - Sarah", "M - Alexander"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewData = findViewById(R.id.listView_data);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, arrayNombres);
        listViewData.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
        //return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        double numeroasistencia = 0;
        double hombres = 0;
        double mujeres = 0;
        if(id == R.id.item_done){
            String itemSelected = "Datos del evento: \n";
            for(int i=0;i<listViewData.getCount();i++){
                if(listViewData.isItemChecked(i)){
                    numeroasistencia++;
                    if(listViewData.getItemAtPosition(i).toString() == "M - Otto"
                            || listViewData.getItemAtPosition(i).toString() == "M - Manuel"
                            || listViewData.getItemAtPosition(i).toString() == "M - Alejandro"
                            || listViewData.getItemAtPosition(i).toString() == "M - Roberto"
                            || listViewData.getItemAtPosition(i).toString() == "M - Jose"
                            || listViewData.getItemAtPosition(i).toString() == "M - Alexander")
                    {
                        hombres++;
                    }
                    if(listViewData.getItemAtPosition(i).toString() == "F - Zoe"
                            || listViewData.getItemAtPosition(i).toString() == "F - Laura"
                            || listViewData.getItemAtPosition(i).toString() == "F - Maria"
                            || listViewData.getItemAtPosition(i).toString() == "F - Sarah")
                    {
                     mujeres++;
                    }
                }
            }
            double calculoasistencia = numeroasistencia*10;
            double calculonoasistencia = 100-calculoasistencia;
            double calculomales = (hombres / 6)*100;
            double calculofemales = (mujeres/4)*100;
            String asistencia = String.format("%.0f", calculoasistencia) +"%";
            String noasistencia = String.format("%.0f", calculonoasistencia) +"%";
            String malestring = String.format("%.2f", calculomales) + "%";
            String femalestring = String.format("%.0f", calculofemales) + "%";
            itemSelected += "% que asistieron al evento: " + asistencia + "\n";
            itemSelected += "% que no asistieron al evento: " + noasistencia  + "\n";
            itemSelected += "% de hombres que asistieron: " + malestring  + "\n";
            itemSelected += "% de mujeres que asistieron: " + femalestring  + "\n";
            Toast.makeText(this, itemSelected,Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
